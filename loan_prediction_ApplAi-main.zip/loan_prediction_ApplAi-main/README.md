# loan_prediction_ApplAi
Predict if your loan will be accepted or not. This happens by using a labeled data for applicants who applied for a loan before, analyzing these data and using some classification models on it.<br>

I did that in machine learning workshop that was held by [ApplAi](https://github.com/ApplAi2023) "Student Activity at Ain Shams University" lasted 2 weeks..<br>

I used :
- ✅ Logistic Regression
- ✅ KNN
- ✅ SVM
- ✅ ID3
- ✅ Random Forrest

### You can try using it now from here: https://loanprediction.streamlit.app/

## 📜 LICENSE
[MIT](https://github.com/aliabdallah7/loan_prediction_ApplAi/blob/main/LICENSE)
